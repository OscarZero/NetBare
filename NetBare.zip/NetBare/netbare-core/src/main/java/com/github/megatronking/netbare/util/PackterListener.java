package com.github.megatronking.netbare.util;

public interface PackterListener {
    void data(String host,int port,String method,String data);
}
