package com.github.megatronking.netbare.sample.util;

import android.util.Log;

public class Logger {
    static final String TAG = "netbare";
    public static void e(String msg){
        Log.e(TAG,msg);
    }
}
