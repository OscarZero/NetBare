package com.github.megatronking.netbare.sample

import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.os.Handler
import android.os.Message
import android.support.v7.app.AppCompatActivity
import android.text.TextUtils
import android.view.View
import android.widget.*
import com.github.megatronking.netbare.NetBare
import com.github.megatronking.netbare.NetBareConfig
import com.github.megatronking.netbare.NetBareListener
import com.github.megatronking.netbare.http.HttpInjectInterceptor
import com.github.megatronking.netbare.http.HttpInterceptorFactory
import com.github.megatronking.netbare.http.HttpVirtualGatewayFactory
import com.github.megatronking.netbare.sample.deskfloating.DragTableButton
import com.github.megatronking.netbare.sample.deskfloating.SuspendUtils
import com.github.megatronking.netbare.sample.packge.AppInfo
import com.github.megatronking.netbare.sample.packge.AppUtils
import com.github.megatronking.netbare.sample.packge.AppinstallReceiver
import com.github.megatronking.netbare.sample.util.*
import com.github.megatronking.netbare.ssl.JKS
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.IOException


class MainActivity : AppCompatActivity(), NetBareListener {

    companion object {
        private const val REQUEST_CODE_PREPARE = 1
        const val REQUEST_CODE = 100
        const val UPDATEPG = 2
        const val UPDATE_PROGRESS = 3
        const val UPDATE_INSTALL = 4
        const val UPDATE_FAILE = 5
        const val COUNTDOWN_NEXT = 6
        const val COUNTDOWN_UPLOAD= 7
        const val LOAD_TIMER= 8
    }

    //手动停止时使用
    private var isRunNetBare = false
    private lateinit var mNetBare : NetBare

    private lateinit var mActionButton : Button
    private lateinit var mEditText: EditText
    private lateinit var pg: ProgressBar
    private lateinit var packageListView: ListView
    private lateinit var adapter: AppListAdapter
    private lateinit var appinstallReceiver:AppinstallReceiver

    private lateinit var customProgress: CustomProgress

    private var mSys_view: DragTableButton? = null

    private val handler: Handler = @SuppressLint("HandlerLeak")
    object : Handler() {
        override fun handleMessage(msg: Message) {

            Logger.e("msgwaht  = ${msg.what}")
            when(msg.what){
                UPDATEPG->{//更新列表
                    pg.visibility = View.GONE
                    adapter.update(AppUtils.getInstance().applist)
                }
                UPDATE_PROGRESS->{//更新下载进度

                    customProgress.setMessage(msg.obj.toString()+"%")
                }
                UPDATE_INSTALL->{//安装apk
                    customProgress.dismiss()
                    AppUtils.getInstance().installAPK(this@MainActivity)
                }
                UPDATE_FAILE->{//隐藏下载进度
                    customProgress.dismiss()
                }
                COUNTDOWN_NEXT->{//测试结束，停止vpn
                    mNetBare.stop()

                }
                COUNTDOWN_UPLOAD->{//vpn停止后上传数据，kill掉测试app
                    var appinfo = AppUtils.getInstance().currentAppinfo
                    Logger.e("countdown next app ${appinfo.name}")
                    appinfo.createDate = System.currentTimeMillis()
                    AppUtils.getInstance().updateAppinfoMap(appinfo)
                    adapter.update(AppUtils.getInstance().applist)
                    AppUtils.getInstance().addResponse("",null,true)
                    killApp(appinfo)
                }
                LOAD_TIMER->{//轮训计时启动监测
                    prepareNetBare(false)
                }
            }

        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMoonEvent(messageEvent: MessageEvent) {
        Logger.e("msg ${messageEvent.message} ,type ${messageEvent.type}")
        when(messageEvent.type){
            MessageEvent.UPDATEAPP_INSTALL->{//安装或者卸载app通知
                var appinfo = AppUtils.getInstance().getAppinfo(messageEvent.message)
                appinfo.action = "打开"
                AppUtils.getInstance().updateAppinfoMap(appinfo);
                adapter.update(AppUtils.getInstance().applist)
            }
            MessageEvent.UPDATEAPP_REMOVE->{//安装或者卸载app通知
                var appinfo = AppUtils.getInstance().getAppinfo(messageEvent.message)
                appinfo.action = "下载"
                AppUtils.getInstance().updateAppinfoMap(appinfo)
                adapter.update(AppUtils.getInstance().applist)
            }
            MessageEvent.UPLOAD_SUCCESS->{
                if(!isRunNetBare){
                    Logger.e("UPLOAD_SUCCESS isRunnetbare $isRunNetBare")
                    return
                }
                prepareNetBare(false)
            }
            MessageEvent.UPLOAD_FAILED->{
                Toast.makeText(this@MainActivity,"上传失败",Toast.LENGTH_SHORT).show()
            }
        }

    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        mNetBare = NetBare.get()
        isRunNetBare = false

        mEditText = findViewById(R.id.edit_id)
        var deviceId = CommonConfigSp.getInstance().get(CommonConfigSp.DEVICEID,"")
        if (!TextUtils.isEmpty(deviceId)) {
            mEditText.setText(deviceId,TextView.BufferType.EDITABLE)
        }
        mActionButton = findViewById(R.id.action)
        mActionButton.setOnClickListener {
            if (mNetBare.isActive) {
                isRunNetBare = false
                mNetBare.stop()
                handler.removeCallbacksAndMessages(null)
            } else{
                prepareNetBare(true)
            }
        }

        // 监听NetBare服务的启动和停止
        mNetBare.registerNetBareListener(this)

        pg = findViewById(R.id.pg)
        packageListView = findViewById(R.id.package_list)
        adapter = AppListAdapter(this, AppUtils.getInstance().applist) {postion, info, isopen ->

            Logger.e( "postion $postion/ info $info")
            if(isopen){
                val intent2: Intent = packageManager.getLaunchIntentForPackage(info.packageName)
                val classNameString = intent2.component.className //得到app类名

                val intent = Intent()
                intent.action = Intent.ACTION_MAIN
                intent.addCategory(Intent.CATEGORY_LAUNCHER)
                intent.flags = (Intent.FLAG_ACTIVITY_NEW_TASK
                        or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                intent.component = ComponentName(info.packageName, classNameString)
                startActivity(intent)
            }else{

                AppUtils.getInstance().openBrowser(this,info.downlaodUrl)
//                AppUtils.getInstance().downloadAPK(this,info.downlaodUrl,handler)
//                customProgress = CustomProgress.show(this,"下载中...",false,null)
            }

        }

        packageListView.adapter = adapter
        ThreadProxy.getInstance().execute {
            AppUtils.getInstance().loadInstallApp(this)
            AppUtils.getInstance().loadApplist("api/app/list",handler)
        }

        appinstallReceiver = AppinstallReceiver()
        val intentFilter = IntentFilter()
        intentFilter.addAction("android.intent.action.PACKAGE_ADDED")
        intentFilter.addAction("android.intent.action.PACKAGE_REMOVED")
        intentFilter.addDataScheme("package")
        registerReceiver(appinstallReceiver, intentFilter) // 注册广播接收器
        EventBus.getDefault().register(this)
        startService(Intent(this,ForegroundService::class.java))
        setDeskFloatButton()
    }

    override fun onResume() {
        super.onResume()
        adapter.update(AppUtils.getInstance().applist)
    }

    override fun onPause() {
        super.onPause()
        Logger.e("===========######========================")
//        handler.postDelayed({
//            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("netbare://goods:8888/goodsDetail?goodsId=10011002"))
//            startActivity(intent)
//            openApp("com.netbare.sample")
//            AppUtils.getInstance().setTopApp(this)
//            AppUtils.getInstance().bring2Front(this)
//        },2000)
    }

    override fun onStop() {
        super.onStop()
        Logger.e("===========######====stop====================")
    }

    override fun onDestroy() {
        super.onDestroy()
        Logger.e("===========######==destory======================")
        mNetBare.unregisterNetBareListener(this)
        mNetBare.stop()
        unregisterReceiver(appinstallReceiver)
        EventBus.getDefault().unregister(this)
        handler.removeCallbacksAndMessages(null)
        SuspendUtils.removeWindowView(mSys_view, this)
    }

    override fun onServiceStarted() {
        Logger.e("onServiceStarted $isRunNetBare")
        runOnUiThread {
            mActionButton.setText(R.string.stop_netbare)
            if(!isRunNetBare){
                return@runOnUiThread
            }
            openApp(AppUtils.getInstance().currentAppinfo.packageName)
            countDownNext(AppUtils.getInstance().currentAppinfo)
        }
    }

    override fun onServiceStopped() {
        runOnUiThread {
            mActionButton.setText(R.string.start_netbare)
            Logger.e("onServiceStopped------------ $isRunNetBare")

            handler.sendEmptyMessageDelayed(COUNTDOWN_UPLOAD,2000)
            AppUtils.getInstance().setTopApp(this)
        }


    }
    private fun countDownNext(info :AppInfo){
        var time = info.stopTime * 1000;
        Logger.e("countDownNext   $time");
        handler.sendEmptyMessageDelayed(COUNTDOWN_NEXT, time.toLong())
        info.action = "读取中"
        AppUtils.getInstance().updateAppinfoMap(info)
        adapter.update(AppUtils.getInstance().applist)
    }

    private fun openApp(packageName :String){
        val intent2: Intent = packageManager.getLaunchIntentForPackage(packageName)
        val classNameString = intent2.component.className //得到app类名

        val intent = Intent()
        intent.action = Intent.ACTION_MAIN
        intent.addCategory(Intent.CATEGORY_LAUNCHER)
        intent.flags = (Intent.FLAG_ACTIVITY_NEW_TASK
                or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        intent.component = ComponentName(packageName, classNameString)
        startActivity(intent)
    }
    private fun killApp(info:AppInfo){
        try {
            Logger.e("kill app start===========")
            val mActivityManager: ActivityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            mActivityManager.killBackgroundProcesses(info.packageName)
        }catch (e:Exception){
            e.printStackTrace()
            Logger.e("kill app fail ======== ${e.message}")
        }
    }
    private fun prepareNetBare(force :Boolean) {
        handler.removeMessages(LOAD_TIMER)
        var device = mEditText.text;
        if(TextUtils.isEmpty(device)){
            Toast.makeText(this,"请输入deviceid",Toast.LENGTH_SHORT).show()
            return
        }
        CommonConfigSp.getInstance().put(CommonConfigSp.DEVICEID,device.toString())

        var listapp = AppUtils.getInstance().applist
        listapp.forEach {
//            var lasttime = CommonConfigSp.getInstance().get(it.uuid,0L)
//            if(it.createDate > lasttime){
//                lasttime = it.createDate
//            }
            var startdata = System.currentTimeMillis() - it.createDate - it.startTime*1000
            if(AppUtils.getInstance().isOpen(it.packageName) && (startdata > 0 || force)){
                Logger.e("apinfo ${it.toString()}")
                AppUtils.getInstance().currentAppinfo = it
                // 安装自签证书
                if (!JKS.isInstalled(this, App.JSK_ALIAS)) {
                    try {
                        JKS.install(this, App.JSK_ALIAS, App.JSK_ALIAS)
                    } catch(e : IOException) {
                        // 安装失败
                    }
                    return
                }
                // 配置VPN
                val intent = NetBare.get().prepare()
                if (intent != null) {
                    startActivityForResult(intent, REQUEST_CODE_PREPARE)
                    return
                }
//                NetBareConfig.defaultHttpConfig(App.getInstance().getJSK(),
//                        -                interceptorFactories())
                // 启动NetBare服务
                var builder =  NetBareConfig.defaultConfig().newBuilder()
                builder.addAllowedApplication(it.packageName)
                builder.addPackterListener {host, port, method, data ->
                    Logger.e("packterlistener ---------host= $host  port=$port  method=$method")
                    UIThreadHandler.post {
                        AppUtils.getInstance().addTCPUDPRespone(host,port,method)
                    }
                }
                var jks = if(it.deHttps){
                    App.getInstance().getJSK()
                }else{
                    null
                }
                CommonConfigSp.getInstance().put(it.uuid,System.currentTimeMillis())
                builder.setVirtualGatewayFactory(HttpVirtualGatewayFactory(jks, interceptorFactories()))
                isRunNetBare = true
                mNetBare.start(builder.build())
                return
            }
        }
        handler.sendEmptyMessageDelayed(LOAD_TIMER,2000)
        Logger.e("timer +++++");
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK && requestCode == REQUEST_CODE_PREPARE) {
            prepareNetBare(false)
        }
    }

    private fun interceptorFactories() : List<HttpInterceptorFactory> {
//        InterceptorFactory
        // 拦截器范例1：打印请求url
//        val interceptor1 = HttpUrlPrintInterceptor.createFactory()
        //黑名单拦截使用
        val injector = HttpInjectInterceptor.createFactory(RejectHttpInjector())
        // 注入器范例1：替换百度首页logo
//        val injector1 = HttpInjectInterceptor.createFactory(BaiduLogoInjector())
//        // 注入器范例2：修改发朋友圈定位
//        val injector2 = HttpInjectInterceptor.createFactory(WechatLocationInjector())
        // 可以添加其它的拦截器，注入器
        // ...
        return listOf( injector)
    }


    /**
     * 设置桌面悬浮框
     */
    private fun setDeskFloatButton() {
        SuspendUtils.canDrawOverlays(this, REQUEST_CODE)
        mSys_view = DragTableButton(this)
        mSys_view!!.setBackgroundResource(R.drawable.float_bg)
        mSys_view!!.setOnClickListener(View.OnClickListener {
//            Toast.makeText(this@MainActivity, "桌面悬浮框", Toast.LENGTH_SHORT).show()
            AppUtils.getInstance().setTopApp(this)
        })
        SuspendUtils.showDragTableButton(mSys_view, this)
    }

}
